const data =[
    {
        "question":"what is an array",
        "answer":"an array is a lenear data structure that store data items of similar data type"
    },
    {
        "question":"how are element access in an array",
        "answer":"elements in an array are access using their index"
    }
],
body = document.querySelector("body");

const renderFAQ =()=>{
   for(let  i of data){
        const { question,answer} = i?i:[];
        body.innerHTML +=`
        <details>
     <summary>${question}</summary>
     <ul>
         <li>${vanswer}</li>
     </ul>
    </details>
        `
   }
}

renderFAQ()


let name ="hello bryan"
name=name.slice(5)

console.log(Math)