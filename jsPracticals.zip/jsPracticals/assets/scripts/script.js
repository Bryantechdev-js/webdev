// const display=(data)=>{
//     console.log(data)
// }

// let name = "hello bryan tech"
// display(name.substr(6,5))
// name=name.concat(", the hunted dev")
// display(name)
// name=name.split(" ")
// display(name)
// name=name.join("+")
// display(name.replace("+","-"))
// let newval=true

// newval =  parseFloat( " ".concat(true))
// newval = new  Array( "")
// display(typeof newval)
// display(this.document.querySelector("body"))


// const object={
//     "name":"bryan tech",
//     "age":"unknown",
//     display(val){
//         console.log(this.val)
//     }
// }

//  object.display("name")



//  const dis = function(a){
//        console.log(this)
//        return function(b){
//          return a + b
//        }
       
//  }

//  const result =dis(5)(5)
//  console.log(result)
 
//  class user{
//     constructor(name,age){
//         name=name;
//         age=age;
//     }


//     getUserInfo(val) {
//         this.name = val;
//         this.val= val.slice(0,5).concat(" " + val.substr(6));
//         this.valAge =20 
       
//     }

//     get(){
//         console.log( " this is the name : " + this.name)
//         console.log(" this is the age:    " + this.valAge)
//     }

//     // this.getUserInfo("bryan tech")
//  }

//  const key = new user("bryan tech",21)
//  key.getUserInfo("bryan tech")
//  key.get()

// const heading = document.querySelector("h1")
// console.log(heading.innerText)
// const innerHTML = heading.innerHTML=`<span> hello  </span>`
// console.log(heading.innerHTML, " this is my span tag innerHTML: " + innerHTML)



// primitive data type

// int ,  whole numbers 1
// Boolean true , false
// , String  chain of charactars `bryan tech`
// undefined
// null
// float  decimal number number 2.2




// none primitive data type

// Array,   const array =[1,2,3,4,5]
// object,  const object ={}
// class,   class user {} 


// const buttle = "water";

// let num=null;
// console.log("this is the variable num " + num)
// const nun1=1;
// let num2;
// let num3=2;
// const result = nun1 + num2;
// result = num2 - nun1;
// console.log(result)

// for(let i =0; i<=10;i++){
//     console.log(i)
// }


function num(){
    
    let num1=5;
    let num2=6;

    return {
        num1 , num2
    }
}

function addNumbers(){
     
      const{num1,num2} = num()

      return num1 + num2
}

const result = addNumbers()

console.log(result)

// const getSearch=async()=>{
//     const data =  await fetch(`https://google.com/search?q=${"money"}`,{
//         method:"POST",
//         content:"application/json"
//     }).json()

//     console.log(data)
// }

// getSearch()













