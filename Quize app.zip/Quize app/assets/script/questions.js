const questions = [
    {
        category:"programing",
        questions:[
            {
                question:"what are loops in programing",
                option:[
                    "loops are circles that are use to create cars"," loops is a reserve key word","loops is use to add and subtract values"," loops are use to perfurm a block of code repeatatly "
                ],
                answer:3
            },
            {
                question:"In javascript, how do you create a function?",
                option:[
                    "create function myFunction()","function myFunction()","def function myFunction()","func myFunction()"
                ],
                answer:1
            },
            {
                question:"what does HTML stand for ?",
                option:[
                    "Hyper text preprocessor","Hyper Text Markup Language","Hyper Text Mulutiple Language","Hyper Tool Multi Language"
                ],
                answer:1
            },
            {
                question:"which of the following is correct way to declare a variable in javascript ?",
                option:[
                    "const x = 10; "," cost x = 10;","let 1 = 10;","var x+1 = 10;"
                ],
                answer:0
            },
            {
                question:"how do we comment in python ?",
                option:[
                    "// this is a comment // ",";; this is  a comment","/* hello this is a  comment */","this is a comment"
                ],
                answer:2
            }
        ]
    }
]