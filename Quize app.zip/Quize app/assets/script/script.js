const QuestionOptions=document.querySelector(".answer-options");
const nextQuestion = document.querySelector(".next-question-btn");
const QuizeTimer=document.querySelector(".time-duration");
const result =document.querySelector(".ans")
const restart = document.querySelector(".span")
const startGame =  document.querySelector(".start-button")

let noQuestion = 4;
let inteval = null;
let currentQuestionIndex=0;
let quizeCategory = "programing",
questionStatus = document.querySelector(".true")
qestionHistory = [],
SpeachTexts=[];


let curentQuestions = null;


let time = 15;

const startGames =()=>{
  document.querySelectorAll(".category-option").forEach(cat=>{
    cat.addEventListener("click",()=>{
        quizeCategory= cat.textContent;
        console.log(quizeCategory)

    })
  })
  document.querySelector(".config-container").style="display:none"
  document.querySelector(".quiz-container").style="display:block;"
  renderQuestions()
}

const splitText =(ArrayData)=>{
  const words = ArrayData.split(" ");
  console.log(words)
  return words
}

let index=0;
const speak =()=>{
    const recognition = new SpeechSynthesisUtterance();
    recognition.lang="en"
    recognition.text=splitText("  ")[index];
    window.speechSynthesis.speak(recognition);
    let timer =setTimeout(()=>{
        index+=1;
        speak()
    },0)
    if(index === 2){
        clearTimeout(timer)
    }
}


const resetimer =()=>{
    time=26
    QuizeTimer.textContent=`${26}s`
}
const Timer=()=>{
    // // console.log(QuizeTimer.value)
    inteval =setInterval(()=>{
         if(time <= 0){
             // alert("if worked")
             highlightCorrectAnswer()
             clearInterval(inteval)
             resetimer()
             setTimeout(()=>{

                 renderQuestions()
             },2000)

            
         }
         time=time - 1;
         QuizeTimer.textContent=`${time}s`;
         Timer()
        },5000)
    
    
    
    

}



const getRandomQuestions =()=>{
    const categeryQuestions = questions.find(cat => cat.category= quizeCategory.toLocaleLowerCase()).questions  || [];

    if(qestionHistory.length  >= Math.min(categeryQuestions.length, nextQuestion)){
        return console.log("completed");
    }
    
    // make sure the questions dont repeat
    const avaliableQuestion = categeryQuestions.filter((_,index)=> !qestionHistory.includes(index));
    // console.log(RandomQuestions)
    
    const RandomQuestions = avaliableQuestion[Math.floor(Math.random() *  avaliableQuestion.length)]
    qestionHistory.push(categeryQuestions.indexOf(RandomQuestions))
    return RandomQuestions;
}
let Qnum=0;
const updatePassQuestionNo =()=>{
    Qnum+=1;
    questionStatus.textContent=Qnum;
    console.log(Qnum)
    if(Qnum === 4){
        result.textContent=Qnum;
        document.querySelector(".quiz-container").style="display:none;"
        document.querySelector(".result-container").style="display:block;"
    }
    
}

const  highlightCorrectAnswer = (correctIndex) =>{
        document.querySelectorAll(".answer-option")[correctIndex || currentQuestionIndex ].classList.add("correct");
}

const handleAnswer =(option,index)=>{
    const isCorrect =  curentQuestions.answer == index;
    option.classList.add(isCorrect ? "correct" : "incorrect");
    

    document.querySelectorAll(".answer-option").forEach((clickedOption)=>{
          clickedOption.style.pointerEvents = "none"
        //   clickedOption.style="cursor:none;"
    });

    !isCorrect ? highlightCorrectAnswer(curentQuestions.answer) : updatePassQuestionNo()
}

const renderQuestions =()=>{
    QuestionOptions.innerHTML="";
    curentQuestions = getRandomQuestions()
    console.log(curentQuestions)
    if(!curentQuestions)return;
    
    document.querySelector(".quiz-question-text").textContent=curentQuestions.question;
  curentQuestions.option.forEach((answer,i)=>{
      const li = document.createElement("li")
      li.classList.add("answer-option")
      li.textContent=answer;
      QuestionOptions.appendChild(li);
      currentQuestionIndex=curentQuestions.answer;
      li.addEventListener("click",()=>handleAnswer(li,i))
    })
    resetimer()
    Timer()
}
renderQuestions()

nextQuestion.addEventListener("click",renderQuestions);
restart.addEventListener("click",()=>{
    Qnum=0;
    window.location=""
}
)
startGame.addEventListener("click",()=>startGames())